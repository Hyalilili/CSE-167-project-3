#ifndef CSE167_UpdateData_h
#define CSE167_UpdateData_h

#include <iostream>

class UpdateData
{
    
public:
    
    double dt;
    //Place any objects here that you want to pass to an update() call
    
    UpdateData(void);
    virtual ~UpdateData(void);
    
};

#endif
