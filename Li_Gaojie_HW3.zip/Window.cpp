#include <iostream>

#ifdef __APPLE__
    #include <GLUT/glut.h>
#else
    #include <GL/glut.h>
#endif

#include "Window.h"
#include "Cube.h"
#include "Matrix4.h"
#include "Globals.h"
#include "Vector3.h"
#include "Rasterizer.h"
#include "House.h"

int Window::width  = 512;   //Set window width in pixels here
int Window::height = 512;   //Set window height in pixels here
float spin_speed = 0.005;
int mode = 0;   //Mode for whether display house or cube.
bool rast_mode = false;
int timebase = 0;
float fps;
int frame = 0;
//bool debug_mode = false;


void Window::initialize(void)
{
    //Setup the light
    Vector4 lightPos(0.0, 10.0, 15.0, 1.0);
    Globals::light.position = lightPos;
    Globals::light.quadraticAttenuation = 0.02;
    
    //Initialize cube matrix:
    Globals::cube.toWorld.identity();
    
    //Setup the cube's material properties
    Color color(0x23ff27ff);
    Globals::cube.material.color = color;
}

//----------------------------------------------------------------------------
// Callback method called when system is idle.
// This is called at the start of every new "frame" (qualitatively)
void Window::idleCallback()
{
    //Set up a static time delta for update calls
    Globals::updateData.dt = 1.0/60.0;// 60 fps
    
    //Rotate cube; if it spins too fast try smaller values and vice versa
    Globals::cube.spin(spin_speed);
    
    //Call the update function on cube
    Globals::cube.update(Globals::updateData);
    
    int startTime = glutGet(GLUT_ELAPSED_TIME);
    frame++;
    
    if (startTime - timebase > 1000) {
        std::string time = "current";
        fps = frame*1000.0/(startTime-timebase);
        printf("FPS:%4.2f",
               frame*1000.0/(startTime-timebase));
        printf("\n");
        timebase = startTime;
        frame = 0;
    }
    
    //Call the display routine to draw the cube
    displayCallback();
}

//----------------------------------------------------------------------------
// Callback method called by GLUT when graphics window is resized by the user
void Window::reshapeCallback(int w, int h)
{
    width = w;                                                       //Set the window width
    height = h;                                                      //Set the window height
    glViewport(0, 0, w, h);                                          //Set new viewport size
    glMatrixMode(GL_PROJECTION);                                     //Set the OpenGL matrix mode to Projection
    glLoadIdentity();                                                //Clear the projection matrix by loading the identity
    gluPerspective(60.0, double(width)/(double)height, 1.0, 1000.0); //Set perspective projection viewing frustum
    Globals::raster.reshape(w, h);
}

//----------------------------------------------------------------------------
// Callback method called by GLUT when window readraw is necessary or when glutPostRedisplay() was called.
void Window::displayCallback()
{
    //Clear color and depth buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    //Set the OpenGL matrix mode to ModelView
    glMatrixMode(GL_MODELVIEW);
    
    //Push a matrix save point
    //This will save a copy of the current matrix so that we can
    //make changes to it and 'pop' those changes off later.
    glPushMatrix();
    
    //Replace the current top of the matrix stack with the inverse camera matrix
    //This will convert all world coordiantes into camera coordiantes
    glLoadMatrixf(Globals::camera.getInverseMatrix().ptr());
    
    //Bind the light to slot 0.  We do this after the camera matrix is loaded so that
    //the light position will be treated as world coordiantes
    //(if we didn't the light would move with the camera, why is that?)
    Globals::light.bind(0);
    
    //Switch case to decide whether display house or cube.
    switch (mode) {
        case 0:
            //Draw the cube!
            glEnable(GL_LIGHTING);
            if (rast_mode == false) {
                Globals::cube.draw(Globals::drawData);
            }
            else {
                Globals::cube.rast_draw(Globals::drawData);
            }
            break;
            
        case 1:
            //Draw the house
            glDisable(GL_LIGHTING);
            if (rast_mode == false) {
                Globals::house.draw(Globals::drawData);
            }
            else {
                Globals::house.rast_Draw(Globals::drawData);
            }            break;
            
        case 2:
            //Draw the bunny
            glEnable(GL_LIGHTING);
            
            if (rast_mode == false) {
                Globals::bunny.draw(Globals::drawData);
            }
            else {
                Globals::bunny.Rast_Draw(Globals::drawData);
            }
            
            break;
            
        case 3:
            //Draw the dragon
            glEnable(GL_LIGHTING);

            if (rast_mode == false) {
                Globals::dragon.draw(Globals::drawData);
            }
            else {
                Globals::dragon.Rast_Draw(Globals::drawData);
            }
            
            break;
        
        case 4:
            //Draw the bear
            glEnable(GL_LIGHTING);
            
            if (rast_mode == false) {
                Globals::bear.draw(Globals::drawData);
            }
            else {
                Globals::bear.Rast_Draw(Globals::drawData);
            }
            
            break;
            
        default:
            break;
    }
    
    //Pop off the changes we made to the matrix stack this frame
    glPopMatrix();
    
    //Tell OpenGL to clear any outstanding commands in its command buffer
    //This will make sure that all of our commands are fully executed before
    //we swap buffers and show the user the freshly drawn frame
    glFlush();
    
    //Swap the off-screen buffer (the one we just drew to) with the on-screen buffer
    glutSwapBuffers();
}

void Window::keyboardCallback(unsigned char key_press, int x, int y) {
    Matrix4 change;
    
    switch (key_press) {
        // If press lower case c: change between counter clockwize and clockwize
        case 'c':
            spin_speed = -spin_speed;
            break;
            
        // If press lower case s: scale down the cube
        case 's':
            change.makeScale(0.9, 0.9, 0.9);
            if (mode == 0)
                Globals::cube.toWorld = Globals::cube.toWorld * change;
            else if (mode == 2)
                Globals::bunny.toWorld = Globals::bunny.toWorld * change;
            else if (mode == 3)
                Globals::dragon.toWorld = Globals::dragon.toWorld * change;
            else if (mode == 4)
                Globals::bear.toWorld = Globals::bear.toWorld * change;
            break;
            
        // If press upper case S: scale up the cube
        case 'S':
            change.makeScale(1.1, 1.1, 1.1);
            if (mode == 0)
                Globals::cube.toWorld = Globals::cube.toWorld * change;
            else if (mode == 2)
                Globals::bunny.toWorld = Globals::bunny.toWorld * change;
            else if (mode == 3)
                Globals::dragon.toWorld = Globals::dragon.toWorld * change;
            else if (mode == 4)
                Globals::bear.toWorld = Globals::bear.toWorld * change;
            break;
            
        // If press lower case x: move the cube left for small amount
        case 'x':
            change.makeTranslate(-1, 0, 0);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
        
        // If press upper case X: move the cube right for small amount
        case 'X':
            change.makeTranslate(1, 0, 0);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
           
        // If press lower case y: move the cube up for small amount
        case 'y':
            change.makeTranslate(0, -1, 0);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
            
        // If press upper case Y: move the cube down for small amount
        case 'Y':
            change.makeTranslate(0, 1, 0);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
            
        // If press lower case z: move the cube in for small amount
        case 'z':
            change.makeTranslate(0, 0, -1);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
            
        // If press upper case Z: move the cube out for small amount
        case 'Z':
            change.makeTranslate(0, 0, 1);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
            
        // On keypress of r: reset the cube to original state
        case 'r':
            if (mode == 0)
                Globals::cube.toWorld.identity();
            else if (mode == 2)
                Globals::bunny.toWorld.identity();
            else if (mode == 3)
                Globals::dragon.toWorld.identity();
            else if (mode == 4)
                Globals::bear.toWorld.identity();
            break;
       
        // On keypress of lower case o: rotate the cube counterclockwise for a small angle
        case 'o':
            change.makeRotateZ(0.1);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
            
        // On keypress of upper case O: rotate the cube clockwise for a small angle
        case 'O':
            change.makeRotateZ(-0.1);
            if (mode == 0)
                Globals::cube.toWorld = change * Globals::cube.toWorld;
            else if (mode == 2)
                Globals::bunny.toWorld = change * Globals::bunny.toWorld;
            else if (mode == 3)
                Globals::dragon.toWorld = change * Globals::dragon.toWorld;
            else if (mode == 4)
                Globals::bear.toWorld = change * Globals::bear.toWorld;
            break;
            
        case 'e':
            if (rast_mode == false){
                rast_mode = true;
                Globals::raster.part = 0;
                Globals::raster.debug_mode = false;
            }
            else
                rast_mode = false;
            
            break;
            
        case '+':
            if (Globals::raster.part < 4 && (rast_mode == true)) {
                Globals::raster.part++;
            }
            break;
            
        case '-':
            if (Globals::raster.part > 0 && (rast_mode == true)) {
                Globals::raster.part--;
            }
            break;
            
        case 'd':
            Globals::raster.debug_mode = !Globals::raster.debug_mode;
            break;

        default:
            break;
    }
    
    // Print position of the cube
    if (mode == 0) {
        Vector3 position = Vector3(Globals::cube.toWorld.get(3, 0),
                                   Globals::cube.toWorld.get(3, 1),
                                   Globals::cube.toWorld.get(3, 2));
        position.print("cube");
    }
    else if (mode == 2) {
        Vector3 position = Vector3(Globals::bunny.toWorld.get(3, 0),
                                   Globals::bunny.toWorld.get(3, 1),
                                   Globals::bunny.toWorld.get(3, 2));
        position.print("bunny");
    }
    else if (mode == 3) {
        Vector3 position = Vector3(Globals::dragon.toWorld.get(3, 0),
                                   Globals::dragon.toWorld.get(3, 1),
                                   Globals::dragon.toWorld.get(3, 2));
        position.print("dragon");
    }
    else if (mode == 4) {
        Vector3 position = Vector3(Globals::bear.toWorld.get(3, 0),
                                   Globals::bear.toWorld.get(3, 1),
                                   Globals::bear.toWorld.get(3, 2));
        position.print("bear");
    }
}


//TODO: Keyboard callbacks!
void Window::functionKeyboardCallback(int key_press, int x, int y) {
    switch (key_press) {
        // Draw the cube
        case GLUT_KEY_F1:
            mode = 0;
            Globals::camera.reset_Cam();
            Globals::raster.drawMode = 0;
            break;
            
        case GLUT_KEY_F2:
            mode = 1;
            
            Globals::camera.e.set(0, 24.14, 24.14);
            Globals::camera.d.set(0, 0, 0);
            Globals::camera.up.set(0, 1, 0);
            
            Globals::camera.update();
            Globals::raster.drawMode = 1;
            rast_mode = false;
            break;
            
        case GLUT_KEY_F3:
            mode = 1;
            
            Globals::camera.e.set(-28.33, 11.66, 23.33);
            Globals::camera.d.set(-5, 0, 0);
            Globals::camera.up.set(0, 1, 0.5);
            
            Globals::camera.update();
            Globals::raster.drawMode = 2;
            rast_mode = false;
            break;
            
        case GLUT_KEY_F4:
            mode = 2;
            Globals::raster.drawMode = 3;
            Globals::camera.reset_Cam();
            rast_mode = false;
            break;
            
        case GLUT_KEY_F5:
            mode = 3;
            Globals::raster.drawMode = 4;
            Globals::camera.reset_Cam();
            rast_mode = false;
            break;
            
        case GLUT_KEY_F6:
            mode = 4;
            Globals::raster.drawMode = 5;
            Globals::camera.reset_Cam();
            rast_mode = false;
            break;
            
        default:
            break;
    }
}
//TODO: Function Key callbacks!

//TODO: Mouse callbacks!

//TODO: Mouse Motion callbacks!
