#include "Globals.h"
#include "Rasterizer.h"
#include "Cube.h"
#include "House.h"

Camera Globals::camera;

Cube Globals::cube(10.0);

Light Globals::light;

House Globals::house;

OBJObject Globals::bunny = OBJObject("bunny.obj");
OBJObject Globals::dragon = OBJObject("dragon.obj");
OBJObject Globals::bear = OBJObject("bear.obj");

Rasterizer Globals::raster = Rasterizer();

DrawData Globals::drawData;
UpdateData Globals::updateData;