//
//  House.hpp
//  CSE167 Spring 2015 Starter Code
//
//  Created by Gaojie Li on 10/7/15.
//  Copyright © 2015 RexWest. All rights reserved.
//

#ifndef House_h
#define House_h

#include "Drawable.h"

class House:public Drawable {
    
public:
    int nVerts;
    
    House();
    // Destructor
    virtual ~House(void);
    // Draw method
    virtual void draw(DrawData&);
};

#endif /* House_h */
