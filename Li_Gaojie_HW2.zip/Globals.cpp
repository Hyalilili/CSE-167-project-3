#include "Globals.h"

Camera Globals::camera;

Cube Globals::cube(10.0);

Light Globals::light;

House Globals::house;

OBJObject Globals::bunny = OBJObject("bunny.obj");
OBJObject Globals::dragon = OBJObject("dragon.obj");
OBJObject Globals::bear = OBJObject("bear.obj");

DrawData Globals::drawData;
UpdateData Globals::updateData;